import Neutrinos.SelfScatter
#print axioms Neutrinos.SelfScatter.selfScatterEnergy
#print axioms Neutrinos.SelfScatter.selfScatterEnergy_ab
#print axioms Neutrinos.SelfScatter.selfScatterEnergy_no_nn
