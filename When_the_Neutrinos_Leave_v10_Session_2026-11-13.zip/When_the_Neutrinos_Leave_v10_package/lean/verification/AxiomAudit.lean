import Neutrinos.CrossLink
import Neutrinos.Frobenius
import Neutrinos.TwoMoment
import Neutrinos.SplitRate
import Neutrinos.Shear
import Neutrinos.ShearComplex
import Neutrinos.Propagator
import Neutrinos.KillLine
import Neutrinos.Memory
import Neutrinos.SelfScatter

#print axioms Neutrinos.CrossLink.norm_cross_product
#print axioms Neutrinos.CrossLink.crossLink
#print axioms Neutrinos.CrossLink.crossLink_sq
#print axioms Neutrinos.CrossLink.crossLink_sq_k
#print axioms Neutrinos.Frobenius.frobSq_two
#print axioms Neutrinos.Frobenius.frobSq_three
#print axioms Neutrinos.Frobenius.norm_sq_I_mul_real
#print axioms Neutrinos.Frobenius.star_negI_mul
#print axioms Neutrinos.Frobenius.star_neg_real
#print axioms Neutrinos.TwoMoment.L2_00
#print axioms Neutrinos.TwoMoment.L2_01
#print axioms Neutrinos.TwoMoment.L2_10
#print axioms Neutrinos.TwoMoment.L2_11
#print axioms Neutrinos.TwoMoment.sc_00
#print axioms Neutrinos.TwoMoment.sc_11
#print axioms Neutrinos.TwoMoment.sc_01
#print axioms Neutrinos.TwoMoment.sc_10
#print axioms Neutrinos.TwoMoment.twoMomentEnergy_c
#print axioms Neutrinos.TwoMoment.twoMomentConnectionEnergy
#print axioms Neutrinos.SplitRate.L3_00
#print axioms Neutrinos.SplitRate.L3_01
#print axioms Neutrinos.SplitRate.L3_02
#print axioms Neutrinos.SplitRate.L3_10
#print axioms Neutrinos.SplitRate.L3_11
#print axioms Neutrinos.SplitRate.L3_12
#print axioms Neutrinos.SplitRate.L3_20
#print axioms Neutrinos.SplitRate.L3_21
#print axioms Neutrinos.SplitRate.L3_22
#print axioms Neutrinos.SplitRate.sc_00
#print axioms Neutrinos.SplitRate.sc_02
#print axioms Neutrinos.SplitRate.sc_20
#print axioms Neutrinos.SplitRate.sc_11
#print axioms Neutrinos.SplitRate.sc_22
#print axioms Neutrinos.SplitRate.sc_01
#print axioms Neutrinos.SplitRate.sc_10
#print axioms Neutrinos.SplitRate.sc_12
#print axioms Neutrinos.SplitRate.sc_21
#print axioms Neutrinos.SplitRate.splitRateEnergy_ab
#print axioms Neutrinos.SplitRate.splitRateEnergy
#print axioms Neutrinos.SplitRate.splitRateEnergy_equal_rates
#print axioms Neutrinos.Shear.R00_one
#print axioms Neutrinos.Shear.cf_one
#print axioms Neutrinos.Shear.R00_eq_cf
#print axioms Neutrinos.Shear.cf_hasDerivAt
#print axioms Neutrinos.Shear.R00_hasDerivAt
#print axioms Neutrinos.Shear.R00_derivative_formula_at_one
#print axioms Neutrinos.Shear.energy_hasDerivAt
#print axioms Neutrinos.Shear.shearEnergy_hasDerivAt
#print axioms Neutrinos.Shear.energy_derivative_zero_at_equal
#print axioms Neutrinos.Shear.shearCounterexample
#print axioms Neutrinos.ShearComplex.A00
#print axioms Neutrinos.ShearComplex.A01
#print axioms Neutrinos.ShearComplex.A02
#print axioms Neutrinos.ShearComplex.A10
#print axioms Neutrinos.ShearComplex.A11
#print axioms Neutrinos.ShearComplex.A12
#print axioms Neutrinos.ShearComplex.A20
#print axioms Neutrinos.ShearComplex.A21
#print axioms Neutrinos.ShearComplex.A22
#print axioms Neutrinos.ShearComplex.det_Aresp
#print axioms Neutrinos.ShearComplex.inv_00
#print axioms Neutrinos.ShearComplex.cofactor_00
#print axioms Neutrinos.ShearComplex.resolvent_00_eq_cf
#print axioms Neutrinos.ShearComplex.resolvent_00_at_one
#print axioms Neutrinos.Propagator.commute_real_smul_one
#print axioms Neutrinos.Propagator.exp_real_smul_one
#print axioms Neutrinos.Propagator.scalarCollisionPropagator
#print axioms Neutrinos.Propagator.commute_shifted
#print axioms Neutrinos.Propagator.commute_generators
#print axioms Neutrinos.Propagator.two_step_propagator
#print axioms Neutrinos.KillLine.G_D
#print axioms Neutrinos.KillLine.G_C
#print axioms Neutrinos.KillLine.G_B
#print axioms Neutrinos.KillLine.testD_verdict
#print axioms Neutrinos.KillLine.testC_verdict
#print axioms Neutrinos.KillLine.testB_verdict
#print axioms Neutrinos.Memory.selfadjoint_line_iff
#print axioms Neutrinos.Memory.rank_one_nilpotent
#print axioms Neutrinos.Memory.nilpotent_null
#print axioms Neutrinos.Memory.offset_gap_identity
#print axioms Neutrinos.Memory.offset_gap_nonneg
#print axioms Neutrinos.Memory.one_mode_speed
#print axioms Neutrinos.Memory.ladder_middle_rung
#print axioms Neutrinos.Memory.ledger_reads_constant
#print axioms Neutrinos.SelfScatter.selfScatterEnergy_ab
#print axioms Neutrinos.SelfScatter.selfScatterEnergy
#print axioms Neutrinos.SelfScatter.selfScatterEnergy_no_nn
